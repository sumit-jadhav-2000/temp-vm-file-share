/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    TYPE_SUSER = 258,              /* TYPE_SUSER  */
    TYPE_SGROUP = 259,             /* TYPE_SGROUP  */
    TYPE_SGID = 260,               /* TYPE_SGID  */
    TYPE_SUID = 261,               /* TYPE_SUID  */
    TYPE_MAX = 262,                /* TYPE_MAX  */
    TYPE_MAXNICKLEN = 263,         /* TYPE_MAXNICKLEN  */
    TYPE_GAME_SHORT_NAME = 264,    /* TYPE_GAME_SHORT_NAME  */
    TYPE_WATCH_SORTMODE = 265,     /* TYPE_WATCH_SORTMODE  */
    TYPE_BANNERVARS = 266,         /* TYPE_BANNERVARS  */
    TYPE_ALLOW_REGISTRATION = 267, /* TYPE_ALLOW_REGISTRATION  */
    TYPE_WATCH_COLUMNS = 268,      /* TYPE_WATCH_COLUMNS  */
    TYPE_GAME_ID = 269,            /* TYPE_GAME_ID  */
    TYPE_PATH_GAME = 270,          /* TYPE_PATH_GAME  */
    TYPE_NAME_GAME = 271,          /* TYPE_NAME_GAME  */
    TYPE_PATH_DGLDIR = 272,        /* TYPE_PATH_DGLDIR  */
    TYPE_PATH_SPOOL = 273,         /* TYPE_PATH_SPOOL  */
    TYPE_PATH_BANNER = 274,        /* TYPE_PATH_BANNER  */
    TYPE_PATH_CANNED = 275,        /* TYPE_PATH_CANNED  */
    TYPE_PATH_CHROOT = 276,        /* TYPE_PATH_CHROOT  */
    TYPE_PATH_PASSWD = 277,        /* TYPE_PATH_PASSWD  */
    TYPE_PATH_LOCKFILE = 278,      /* TYPE_PATH_LOCKFILE  */
    TYPE_PATH_TTYREC = 279,        /* TYPE_PATH_TTYREC  */
    TYPE_MALSTRING = 280,          /* TYPE_MALSTRING  */
    TYPE_PATH_INPROGRESS = 281,    /* TYPE_PATH_INPROGRESS  */
    TYPE_GAME_ARGS = 282,          /* TYPE_GAME_ARGS  */
    TYPE_RC_FMT = 283,             /* TYPE_RC_FMT  */
    TYPE_CMDQUEUE = 284,           /* TYPE_CMDQUEUE  */
    TYPE_DEFINE_MENU = 285,        /* TYPE_DEFINE_MENU  */
    TYPE_BANNER_FILE = 286,        /* TYPE_BANNER_FILE  */
    TYPE_CURSOR = 287,             /* TYPE_CURSOR  */
    TYPE_POSTCMDQUEUE = 288,       /* TYPE_POSTCMDQUEUE  */
    TYPE_TIMEFORMAT = 289,         /* TYPE_TIMEFORMAT  */
    TYPE_MAX_IDLE_TIME = 290,      /* TYPE_MAX_IDLE_TIME  */
    TYPE_MENU_MAX_IDLE_TIME = 291, /* TYPE_MENU_MAX_IDLE_TIME  */
    TYPE_EXTRA_INFO_FILE = 292,    /* TYPE_EXTRA_INFO_FILE  */
    TYPE_ENCODING = 293,           /* TYPE_ENCODING  */
    TYPE_LOCALE = 294,             /* TYPE_LOCALE  */
    TYPE_UTF8ESC = 295,            /* TYPE_UTF8ESC  */
    TYPE_FILEMODE = 296,           /* TYPE_FILEMODE  */
    TYPE_DEFTERM = 297,            /* TYPE_DEFTERM  */
    TYPE_FLOWCTRL = 298,           /* TYPE_FLOWCTRL  */
    TYPE_VALUE = 299,              /* TYPE_VALUE  */
    TYPE_NUMBER = 300,             /* TYPE_NUMBER  */
    TYPE_CMDQUEUENAME = 301,       /* TYPE_CMDQUEUENAME  */
    TYPE_DGLCMD0 = 302,            /* TYPE_DGLCMD0  */
    TYPE_DGLCMD1 = 303,            /* TYPE_DGLCMD1  */
    TYPE_DGLCMD2 = 304,            /* TYPE_DGLCMD2  */
    TYPE_DEFINE_GAME = 305,        /* TYPE_DEFINE_GAME  */
    TYPE_BOOL = 306                /* TYPE_BOOL  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define TYPE_SUSER 258
#define TYPE_SGROUP 259
#define TYPE_SGID 260
#define TYPE_SUID 261
#define TYPE_MAX 262
#define TYPE_MAXNICKLEN 263
#define TYPE_GAME_SHORT_NAME 264
#define TYPE_WATCH_SORTMODE 265
#define TYPE_BANNERVARS 266
#define TYPE_ALLOW_REGISTRATION 267
#define TYPE_WATCH_COLUMNS 268
#define TYPE_GAME_ID 269
#define TYPE_PATH_GAME 270
#define TYPE_NAME_GAME 271
#define TYPE_PATH_DGLDIR 272
#define TYPE_PATH_SPOOL 273
#define TYPE_PATH_BANNER 274
#define TYPE_PATH_CANNED 275
#define TYPE_PATH_CHROOT 276
#define TYPE_PATH_PASSWD 277
#define TYPE_PATH_LOCKFILE 278
#define TYPE_PATH_TTYREC 279
#define TYPE_MALSTRING 280
#define TYPE_PATH_INPROGRESS 281
#define TYPE_GAME_ARGS 282
#define TYPE_RC_FMT 283
#define TYPE_CMDQUEUE 284
#define TYPE_DEFINE_MENU 285
#define TYPE_BANNER_FILE 286
#define TYPE_CURSOR 287
#define TYPE_POSTCMDQUEUE 288
#define TYPE_TIMEFORMAT 289
#define TYPE_MAX_IDLE_TIME 290
#define TYPE_MENU_MAX_IDLE_TIME 291
#define TYPE_EXTRA_INFO_FILE 292
#define TYPE_ENCODING 293
#define TYPE_LOCALE 294
#define TYPE_UTF8ESC 295
#define TYPE_FILEMODE 296
#define TYPE_DEFTERM 297
#define TYPE_FLOWCTRL 298
#define TYPE_VALUE 299
#define TYPE_NUMBER 300
#define TYPE_CMDQUEUENAME 301
#define TYPE_DGLCMD0 302
#define TYPE_DGLCMD1 303
#define TYPE_DGLCMD2 304
#define TYPE_DEFINE_GAME 305
#define TYPE_BOOL 306

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 46 "config.y"

	char* s;
	int kt;
	unsigned long i;

#line 175 "y.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
